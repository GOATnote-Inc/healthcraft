"""LLM agent interface for HEALTHCRAFT evaluation.

Provides a model-agnostic agent that interacts with the MCP server
to solve clinical tasks. Supports Claude, GPT, and Gemini models.

Usage:
    agent = create_agent("claude-opus-4-6", api_key="...")
    trajectory = agent.run_task(task, server)
"""

from __future__ import annotations

import base64
import json
import logging
import math
import os
import re
import time
from copy import deepcopy
from pathlib import Path
from typing import Any, Protocol

from healthcraft.mcp.server import HealthcraftServer
from healthcraft.tasks.loader import Task
from healthcraft.trajectory import Trajectory

logger = logging.getLogger("healthcraft.llm.agent")

# Maximum tool call rounds per task (prevent infinite loops)
MAX_TOOL_ROUNDS = 25

# Maximum tokens for agent response
MAX_RESPONSE_TOKENS = 4096


def _claude_omits_temperature(model: str) -> bool:
    """Anthropic Opus 4.7+ deprecated the ``temperature`` parameter — the API
    returns 400 if it is sent.

    Return True when ``model`` is an Opus at version >= 4.7 (so the caller must
    OMIT temperature): 4-7, 4-8, 4-9, 4-10+, and any later major (5-x). Older
    Opus (<= 4-6) and non-Opus Claude models (sonnet/haiku) still accept
    temperature and MUST keep sending it — omitting it there would silently fall
    back to the API-default temperature and break deterministic (temp=0) replay.

    The previous guard was a literal ``"4-7" not in model`` substring test, which
    wrongly sent temperature for claude-opus-4-8/4-9 → 400 → every task became a
    cached reward=0 error trajectory (2026-05-31 v11 audit, finding D4-F1).
    """
    m = re.search(r"opus-(\d+)-(\d+)", model.lower())
    if not m:
        return False
    return (int(m.group(1)), int(m.group(2))) >= (4, 7)


def _is_unsupported_temperature_error(exc: Exception) -> bool:
    """True if an OpenAI-style error is the 'this model only supports the default
    temperature' 400 — emitted by reasoning models (e.g. gpt-5.5, o-series) that
    reject an explicit temperature=0. Detected by message (no SDK-class import),
    mirroring the preflight string match (v11 audit D4-F6)."""
    s = str(exc).lower()
    return "temperature" in s and (
        "does not support" in s or "unsupported_value" in s or "only the default" in s
    )


class ModelClient(Protocol):
    """Protocol for model API clients."""

    def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.0,
        max_tokens: int = MAX_RESPONSE_TOKENS,
    ) -> dict[str, Any]:
        """Send a chat completion request.

        Returns:
            Dict with 'content' (str), 'tool_calls' (list[dict]), 'stop_reason' (str).
            Explicit provider refusal text, when present, is retained as 'refusal'.
        """
        ...


class AnthropicClient:
    """Client for Claude models via the Anthropic API."""

    def __init__(self, api_key: str, model: str = "claude-opus-4-6") -> None:
        self._api_key = api_key
        self._model = model
        self._client: Any = None

    def _ensure_client(self) -> None:
        if self._client is None:
            try:
                import anthropic

                self._client = anthropic.Anthropic(api_key=self._api_key)
            except ImportError:
                raise ImportError("anthropic package required: pip install anthropic")

    def _convert_messages(
        self, messages: list[dict[str, Any]]
    ) -> tuple[str | None, list[dict[str, Any]]]:
        """Convert generic messages to Anthropic format.

        Anthropic requires:
        - System message as separate 'system' parameter
        - Assistant tool calls as content blocks (not 'tool_calls' field)
        - Tool results as role='user' with tool_result content blocks
        """
        system_msg = None
        converted = []

        for msg in messages:
            role = msg["role"]

            if role == "system":
                system_msg = msg["content"]
                continue

            if role == "assistant":
                content_blocks: list[dict[str, Any]] = []
                if msg.get("content"):
                    content_blocks.append({"type": "text", "text": msg["content"]})
                for tc in msg.get("tool_calls", []):
                    content_blocks.append(
                        {
                            "type": "tool_use",
                            "id": tc["id"],
                            "name": tc["name"],
                            "input": tc.get("arguments", {}),
                        }
                    )
                converted.append(
                    {
                        "role": "assistant",
                        "content": content_blocks if content_blocks else msg.get("content", ""),
                    }
                )

            elif role == "tool":
                # Anthropic: tool results go in role=user with tool_result blocks
                # Merge consecutive tool results into one user message
                tool_block = {
                    "type": "tool_result",
                    "tool_use_id": msg.get("tool_call_id", ""),
                    "content": msg.get("content", ""),
                }
                if converted and converted[-1].get("_tool_results"):
                    converted[-1]["content"].append(tool_block)
                else:
                    converted.append(
                        {
                            "role": "user",
                            "content": [tool_block],
                            "_tool_results": True,
                        }
                    )

            else:
                converted.append({"role": role, "content": msg.get("content", "")})

        # Strip internal markers
        for msg in converted:
            msg.pop("_tool_results", None)

        return system_msg, converted

    def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.0,
        max_tokens: int = MAX_RESPONSE_TOKENS,
    ) -> dict[str, Any]:
        self._ensure_client()

        system_msg, converted_messages = self._convert_messages(messages)

        kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": converted_messages,
            "max_tokens": max_tokens,
        }
        # Anthropic Opus 4.7+ deprecated `temperature` (API returns 400); older
        # Opus and non-Opus Claude models still accept it. Version-family check —
        # NOT a literal "4-7" substring (which mis-sent it for 4-8/4-9; D4-F1).
        if not _claude_omits_temperature(self._model):
            kwargs["temperature"] = temperature

        if system_msg:
            kwargs["system"] = system_msg

        if tools:
            kwargs["tools"] = [
                {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "input_schema": t.get("parameters", {"type": "object"}),
                }
                for t in tools
            ]

        response = self._client.messages.create(**kwargs)

        content = ""
        tool_calls = []
        for block in response.content:
            if block.type == "text":
                content += block.text
            elif block.type == "tool_use":
                tool_calls.append(
                    {
                        "id": block.id,
                        "name": block.name,
                        "arguments": block.input,
                    }
                )

        return {
            "content": content,
            "tool_calls": tool_calls,
            "stop_reason": response.stop_reason,
        }


class OpenAIClient:
    """Client for GPT models via the OpenAI API."""

    # Models discovered AT RUNTIME to reject an explicit temperature (reasoning
    # models support only the default temperature=1). Process-shared so the first
    # 400 — typically during preflight — flags the model and every later call
    # omits temperature. Self-healing beats a brittle hardcoded allowlist
    # (gpt-5.4 accepts temperature=0; gpt-5.5 does not). See v11 audit D4-F6.
    _models_reject_temperature: set[str] = set()

    def __init__(self, api_key: str, model: str = "gpt-5.4") -> None:
        self._api_key = api_key
        self._model = model
        self._client: Any = None

    def _ensure_client(self) -> None:
        if self._client is None:
            try:
                import openai

                self._client = openai.OpenAI(api_key=self._api_key)
            except ImportError:
                raise ImportError("openai package required: pip install openai")

    def _convert_messages(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert generic messages to OpenAI format.

        OpenAI requires:
        - Assistant tool_calls with type='function' and function wrapper
        - Tool call arguments as JSON strings (not dicts)
        - Tool results as role='tool' with tool_call_id
        """
        converted = []
        for msg in messages:
            role = msg["role"]

            if role == "assistant" and msg.get("tool_calls"):
                oai_tool_calls = []
                for tc in msg["tool_calls"]:
                    args = tc.get("arguments", {})
                    if isinstance(args, dict):
                        args = json.dumps(args)
                    oai_tool_calls.append(
                        {
                            "id": tc["id"],
                            "type": "function",
                            "function": {
                                "name": tc["name"],
                                "arguments": args,
                            },
                        }
                    )
                converted.append(
                    {
                        "role": "assistant",
                        "content": msg.get("content") or None,
                        "tool_calls": oai_tool_calls,
                    }
                )
            elif role == "tool":
                converted.append(
                    {
                        "role": "tool",
                        "tool_call_id": msg.get("tool_call_id", ""),
                        "content": msg.get("content", ""),
                    }
                )
            else:
                converted.append(msg)

        return converted

    def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.0,
        max_tokens: int = MAX_RESPONSE_TOKENS,
    ) -> dict[str, Any]:
        self._ensure_client()

        converted_messages = self._convert_messages(messages)

        kwargs: dict[str, Any] = {
            "model": self._model,
            "messages": converted_messages,
            "max_completion_tokens": max_tokens,
        }
        # Reasoning models (gpt-5.5, o-series) reject an explicit temperature and
        # only support the default (1). Omit it for any model already known to
        # reject it; otherwise send temperature=0 and self-heal on the 400 below.
        send_temperature = self._model not in OpenAIClient._models_reject_temperature
        if send_temperature:
            kwargs["temperature"] = temperature

        if tools:
            kwargs["tools"] = [
                {
                    "type": "function",
                    "function": {
                        "name": t["name"],
                        "description": t.get("description", ""),
                        "parameters": t.get("parameters", {"type": "object"}),
                    },
                }
                for t in tools
            ]

        try:
            response = self._client.chat.completions.create(**kwargs)
        except Exception as e:
            # Self-heal a reasoning model that rejects temperature=0: drop the
            # param, remember the model, and retry once. The model then samples
            # at its default temperature (1) — non-deterministic, so reproducibility
            # for it rests on the seed + multi-trial aggregation, not temp=0.
            if send_temperature and _is_unsupported_temperature_error(e):
                logger.warning(
                    "%s rejects temperature=%s (reasoning model); retrying without it. "
                    "This model samples at the default temperature — per-trial variance "
                    "is expected; reproducibility relies on seed + trials, not temp=0.",
                    self._model,
                    temperature,
                )
                OpenAIClient._models_reject_temperature.add(self._model)
                kwargs.pop("temperature", None)
                response = self._client.chat.completions.create(**kwargs)
            else:
                raise
        choice = response.choices[0]
        message = choice.message

        tool_calls = []
        if message.tool_calls:
            for tc in message.tool_calls:
                tool_calls.append(
                    {
                        "id": tc.id,
                        "name": tc.function.name,
                        "arguments": json.loads(tc.function.arguments),
                    }
                )

        result = {
            "content": message.content or "",
            "tool_calls": tool_calls,
            "stop_reason": choice.finish_reason,
        }
        refusal = getattr(message, "refusal", None)
        if refusal:
            result["refusal"] = refusal
        return result


class GrokClient(OpenAIClient):
    """Client for Grok models via the xAI API (OpenAI-compatible)."""

    def __init__(self, api_key: str, model: str = "grok-4") -> None:
        super().__init__(api_key=api_key, model=model)

    def _ensure_client(self) -> None:
        if self._client is None:
            try:
                import openai

                self._client = openai.OpenAI(
                    api_key=self._api_key,
                    base_url="https://api.x.ai/v1",
                )
            except ImportError:
                raise ImportError("openai package required: pip install openai")


class SGLangClient(OpenAIClient):
    """Client for SGLang-served open-weights policies (OpenAI-compatible).

    SGLang serves any HuggingFace-compatible chat model behind an
    OpenAI-compatible ``/v1/chat/completions`` endpoint. Tool calling works
    out of the box for tool-capable base models.

    Used by the RL coupling (``healthcraft.rl.env.HealthCraftEnv``): the
    rollout drives multi-turn MCP tool use against a policy this client
    wraps. The training framework (slime) owns weight updates server-side;
    this client only does inference.

    ``api_key`` is forwarded but most SGLang deployments don't enforce one
    — an empty string becomes ``"EMPTY"`` to satisfy the OpenAI SDK.
    ``base_url`` defaults to ``http://localhost:30000/v1`` and can be
    overridden via the ``SGLANG_BASE_URL`` environment variable or the
    constructor argument.
    """

    def __init__(
        self,
        api_key: str = "",
        model: str = "default",
        base_url: str | None = None,
    ) -> None:
        super().__init__(api_key=api_key or "EMPTY", model=model)
        self._base_url = base_url or os.environ.get("SGLANG_BASE_URL", "http://localhost:30000/v1")

    def _ensure_client(self) -> None:
        if self._client is None:
            try:
                import openai

                self._client = openai.OpenAI(
                    api_key=self._api_key,
                    base_url=self._base_url,
                )
            except ImportError:
                raise ImportError("openai package required: pip install openai")


class GeminiClient:
    """Client for Gemini models via the Google Generative AI API."""

    def __init__(self, api_key: str, model: str = "gemini-3.1-pro-preview") -> None:
        self._api_key = api_key
        self._model = model
        self._client: Any = None

    def _ensure_client(self) -> None:
        if self._client is None:
            try:
                from google import genai

                self._client = genai.Client(api_key=self._api_key)
            except ImportError:
                raise ImportError("google-genai package required: pip install google-genai")

    def chat(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.0,
        max_tokens: int = MAX_RESPONSE_TOKENS,
    ) -> dict[str, Any]:
        self._ensure_client()
        from google.genai import types

        # Extract system instruction
        system_text = None
        contents = []
        # Generic IDs correlate our saved messages; Gemini's function response
        # name must instead match FunctionCall.name. Consume IDs per roundtrip
        # because legacy Gemini-generated IDs can recur on later turns.
        pending_calls: dict[str, dict[str, Any]] = {}
        for msg in messages:
            role = msg["role"]
            if role == "system":
                system_text = msg["content"]
                continue
            if role != "tool" and pending_calls:
                raise ValueError("Gemini tool calls have no matching responses before next turn")

            # Map roles: assistant -> model, tool -> function response
            if role == "assistant":
                parts = []
                if msg.get("content"):
                    parts.append(types.Part.from_text(text=msg["content"]))
                for tc in msg.get("tool_calls", []):
                    tc_id = tc.get("id")
                    if not isinstance(tc_id, str) or not tc_id:
                        raise ValueError("Gemini tool call requires a nonempty correlation ID")
                    if tc_id in pending_calls:
                        raise ValueError(f"Gemini tool call ID is already pending: {tc_id}")
                    pending_calls[tc_id] = tc
                    ts = tc.get("thought_signature")
                    provider_id = tc.get("provider_call_id")
                    if ts or provider_id:
                        fc = types.FunctionCall(
                            id=provider_id,
                            name=tc["name"],
                            args=tc.get("arguments", {}),
                        )
                        parts.append(
                            types.Part(
                                function_call=fc,
                                thought_signature=base64.b64decode(ts) if ts else None,
                            )
                        )
                    else:
                        parts.append(
                            types.Part.from_function_call(
                                name=tc["name"],
                                args=tc.get("arguments", {}),
                            )
                        )
                contents.append(types.Content(role="model", parts=parts))
            elif role == "tool":
                tc_id = msg.get("tool_call_id")
                if not isinstance(tc_id, str) or tc_id not in pending_calls:
                    raise ValueError("Gemini tool response has no matching pending function call")
                tc = pending_calls.pop(tc_id)
                result_str = msg.get("content", "{}")
                try:
                    result_data = json.loads(result_str)
                except (json.JSONDecodeError, TypeError):
                    result_data = {"result": result_str}
                response_part = types.Part(
                    function_response=types.FunctionResponse(
                        id=tc.get("provider_call_id"),
                        name=tc["name"],
                        response=result_data,
                    )
                )
                # Parallel results belong in one user Content, in source order.
                # Do not merge them with an ordinary user message.
                if (
                    contents
                    and contents[-1].role == "user"
                    and all(part.function_response for part in contents[-1].parts)
                ):
                    contents[-1].parts.append(response_part)
                else:
                    contents.append(types.Content(role="user", parts=[response_part]))
            else:
                contents.append(
                    types.Content(
                        role="user",
                        parts=[types.Part.from_text(text=msg.get("content", ""))],
                    )
                )

        if pending_calls:
            raise ValueError("Gemini tool calls have no matching responses")

        # Build tool declarations
        tool_declarations = None
        if tools:
            func_decls = []
            for t in tools:
                func_decls.append(
                    types.FunctionDeclaration(
                        name=t["name"],
                        description=t.get("description", ""),
                        parameters=t.get("parameters", {"type": "object", "properties": {}}),
                    )
                )
            tool_declarations = [types.Tool(function_declarations=func_decls)]

        config = types.GenerateContentConfig(
            temperature=temperature,
            max_output_tokens=max_tokens,
            system_instruction=system_text,
            tools=tool_declarations,
        )

        response = self._client.models.generate_content(
            model=self._model,
            contents=contents,
            config=config,
        )

        # Google distinguishes a natural STOP from MAX_TOKENS, safety blocks,
        # invalid function calls, and other incomplete endings. A non-streaming
        # response with no finish reason has not established completion either.
        # https://ai.google.dev/api/generate-content#finishreason
        if not response.candidates:
            feedback = getattr(response, "prompt_feedback", None)
            blocked = getattr(feedback, "block_reason", None)
            blocked_name = getattr(blocked, "value", blocked) or "unknown"
            raise RuntimeError(
                f"Gemini completion returned no candidate (prompt block: {blocked_name})"
            )
        candidate = response.candidates[0]
        finish = getattr(candidate, "finish_reason", None)
        finish_name = getattr(finish, "value", finish) or "missing"
        if finish_name not in {"STOP", "MAX_TOKENS"}:
            raise RuntimeError(f"Gemini completion did not finish successfully: {finish_name}")

        # Parse response
        content = ""
        tool_calls = []
        if candidate.content:
            for part in candidate.content.parts or []:
                if part.text:
                    content += part.text
                elif part.function_call:
                    tc_entry = {
                        "id": f"call_{part.function_call.name}_{len(tool_calls)}",
                        "name": part.function_call.name,
                        "arguments": (
                            dict(part.function_call.args) if part.function_call.args else {}
                        ),
                    }
                    if getattr(part.function_call, "id", None):
                        tc_entry["provider_call_id"] = part.function_call.id
                    if getattr(part, "thought_signature", None):
                        tc_entry["thought_signature"] = base64.b64encode(
                            part.thought_signature
                        ).decode("ascii")
                    tool_calls.append(tc_entry)

        stop_reason = "max_tokens" if finish_name == "MAX_TOKENS" else "stop"
        if tool_calls and finish_name == "STOP":
            stop_reason = "tool_calls"

        return {
            "content": content,
            "tool_calls": tool_calls,
            "stop_reason": stop_reason,
        }


def create_client(model: str, api_key: str) -> ModelClient:
    """Create a model client based on model name.

    Args:
        model: Model identifier (e.g., "claude-opus-4-6", "gpt-5.4",
               "gemini-3.1-pro-preview", "grok-4").
        api_key: API key for the model provider.

    Returns:
        A ModelClient instance.
    """
    m = model.lower()
    if m.startswith("ollama:"):
        from healthcraft.llm.local_models import OllamaClient

        return OllamaClient(model=model[len("ollama:") :])
    if m.startswith("sglang:") or m.startswith("http://") or m.startswith("https://"):
        # Open-weights policy served by SGLang (used by the RL coupling).
        # Two forms:
        #   "sglang:<model-name>"  -> base_url from SGLANG_BASE_URL env
        #   "http(s)://..."        -> the URL IS the base_url; model name
        #                             from SGLANG_MODEL env (default "default")
        # Checked BEFORE vendor-substring routing so an SGLang-served name
        # that happens to contain "claude"/"gpt"/etc. is not misrouted.
        if m.startswith("sglang:"):
            return SGLangClient(api_key=api_key, model=model[len("sglang:") :])
        model_name = os.environ.get("SGLANG_MODEL", "default")
        return SGLangClient(api_key=api_key, model=model_name, base_url=model)
    if "claude" in m or "opus" in m or "sonnet" in m or "haiku" in m:
        return AnthropicClient(api_key=api_key, model=model)
    elif "gpt" in m or "o1" in m or "o3" in m:
        return OpenAIClient(api_key=api_key, model=model)
    elif "gemini" in m:
        return GeminiClient(api_key=api_key, model=model)
    elif "grok" in m:
        return GrokClient(api_key=api_key, model=model)
    else:
        raise ValueError(f"Unknown model provider for: {model}")


def _build_tool_definitions(server: HealthcraftServer) -> list[dict[str, Any]]:
    """Build tool definitions from mcp-tools.json for LLM function calling.

    Loads full JSON Schema parameter definitions so models know what
    arguments each tool accepts. Falls back to sparse definitions if
    the config file is missing.
    """
    tools_config = Path(__file__).parents[3] / "configs" / "mcp-tools.json"
    schema_map: dict[str, dict[str, Any]] = {}
    if tools_config.exists():
        with open(tools_config) as f:
            config = json.load(f)
        schema_map = {t["name"]: t for t in config.get("tools", [])}

    tools = []
    for camel_name in server.available_tools:
        if camel_name in schema_map:
            t = schema_map[camel_name]
            tools.append(
                {
                    "name": t["name"],
                    "description": t.get("description", ""),
                    "parameters": t.get("parameters", {"type": "object", "properties": {}}),
                }
            )
        else:
            tools.append(
                {
                    "name": camel_name,
                    "description": f"HEALTHCRAFT MCP tool: {camel_name}",
                    "parameters": {"type": "object", "properties": {}},
                }
            )
    return tools


def _build_setting_context(setting: dict[str, Any]) -> str:
    """Format task setting data as contextual information for the agent.

    Includes facility status, resource availability, specialist availability,
    and other environmental details that the agent would know as the
    attending physician. Excludes keys already in the system prompt
    (facility, department) and technical keys (world_seed).
    """
    if not setting:
        return ""

    # Keys handled elsewhere (system prompt or inject)
    skip = {"world_seed", "time", "bed"}
    parts: list[str] = []

    for key, value in setting.items():
        if key in skip:
            continue
        label = key.replace("_", " ").title()
        if isinstance(value, dict):
            sub_parts = []
            for k, v in value.items():
                sub_parts.append(f"  {k.replace('_', ' ').title()}: {v}")
            parts.append(f"{label}:\n" + "\n".join(sub_parts))
        elif isinstance(value, list):
            items = "\n".join(f"  - {item}" for item in value)
            parts.append(f"{label}:\n{items}")
        else:
            parts.append(f"{label}: {value}")

    if not parts:
        return ""

    return "\n\n--- Current Department Status ---\n" + "\n".join(parts)


def _copy_response_json(value: Any, ancestors: frozenset[int] = frozenset()) -> Any:
    """Detach a normalized envelope without coercing invalid JSON values.

    This captures the adapter output, not an unobserved native provider envelope.
    Invalid non-JSON objects cannot be faithfully saved and are not stringified.
    """
    if value is None or type(value) in (str, bool, int):
        return value
    if type(value) is float and math.isfinite(value):
        return value
    if type(value) not in (dict, list):
        raise ValueError("Normalized response requires finite JSON values")
    if id(value) in ancestors:
        raise ValueError("Normalized response contains a cycle")
    nested = ancestors | {id(value)}
    if type(value) is list:
        return [_copy_response_json(item, nested) for item in value]
    if any(type(key) is not str for key in value):
        raise ValueError("Normalized response requires string object keys")
    return {key: _copy_response_json(item, nested) for key, item in value.items()}


def _validate_response_batch(response: Any) -> None:
    """Validate the entire request batch before dispatching any state change."""
    if not isinstance(response, dict):
        raise ValueError("Normalized response must be an object")
    if not isinstance(response.get("content"), str):
        raise ValueError("Normalized response content must be a string")
    if not isinstance(response.get("tool_calls"), list):
        raise ValueError("Normalized response tool_calls must be an array")
    for field in ("stop_reason", "refusal"):
        if response.get(field) is not None and not isinstance(response[field], str):
            raise ValueError(f"Normalized response {field} must be a string or null")
    pending_ids: set[str] = set()
    for call in response["tool_calls"]:
        if not isinstance(call, dict):
            raise ValueError("Each tool call must be an object")
        for field in ("id", "name"):
            if not isinstance(call.get(field), str) or not call[field].strip():
                raise ValueError(f"Each tool call requires a nonempty {field}")
        if call["id"] in pending_ids:
            raise ValueError("Simultaneous tool calls require distinct IDs")
        pending_ids.add(call["id"])
        if not isinstance(call.get("arguments", {}), dict):
            raise ValueError("Tool call arguments must be an object")


def run_agent_task(
    client: ModelClient,
    task: Task,
    server: HealthcraftServer,
    system_prompt: str,
) -> Trajectory:
    """Run an LLM agent on a task, capturing the full trajectory.

    The agent interacts with the MCP server via tool calls until it
    either stops calling tools or hits the MAX_TOOL_ROUNDS limit.

    Args:
        client: The model client to use.
        task: The task definition.
        server: The MCP server for tool dispatch.
        system_prompt: The system prompt for the agent.

    Returns:
        A Trajectory capturing the full interaction.
    """
    traj = Trajectory(
        task_id=task.id,
        model="unknown",
        seed=42,
        system_prompt=system_prompt,
        metadata={
            "category": task.category,
            "level": task.level,
            "title": task.title,
            "max_tool_rounds": MAX_TOOL_ROUNDS,
        },
    )

    tools = _build_tool_definitions(server)
    # Preserve the actual advertised interface before passing mutable objects
    # to a client. This is coordinator evidence, never added to model messages.
    traj.metadata["agent_tool_definitions"] = deepcopy(tools)

    # Build user message: task description + setting context
    user_content = task.description
    setting_context = _build_setting_context(task.initial_state)
    if setting_context:
        user_content = user_content.rstrip() + "\n" + setting_context

    messages: list[dict[str, Any]] = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_content},
    ]

    traj.add_turn("system", system_prompt)
    traj.add_turn("user", user_content)

    start_time = time.monotonic()

    for round_num in range(MAX_TOOL_ROUNDS):
        try:
            response = client.chat(messages, tools=tools)
        except Exception as e:
            logger.error("API call failed on round %d: %s", round_num + 1, e)
            traj.error = f"API error on round {round_num + 1}: {e}"
            traj.metadata["stop_reason"] = "client_error"
            break

        captured_response = None
        capture_status = "unavailable"
        try:
            captured_response = _copy_response_json(response)
            capture_status = "captured"
            _validate_response_batch(captured_response)
        except (ValueError, RecursionError) as exc:
            # Return the partial trajectory to the orchestrator. Raising here
            # would lose already completed actions when its assignment fails.
            traj.error = f"Invalid model response on round {round_num + 1}: {exc}"
            traj.metadata["termination_kind"] = "invalid_model_response"
            traj.metadata["stop_reason"] = "invalid_model_response"
            traj.metadata["agent_protocol_error"] = {
                "round": round_num + 1,
                "message": str(exc),
                "capture_status": capture_status,
                "normalized_response": captured_response,
            }
            break
        response = captured_response
        content = response["content"]
        tool_calls = response["tool_calls"]
        stop_reason = response.get("stop_reason")
        traj.metadata["stop_reason"] = stop_reason
        reason = stop_reason if isinstance(stop_reason, str) else None

        # Record assistant turn
        traj.add_turn(
            "assistant",
            content,
            tool_calls=[
                {
                    "id": tc.get("id", ""),
                    "name": tc["name"],
                    "arguments": tc.get("arguments", {}),
                }
                for tc in tool_calls
            ],
        )

        # Add assistant message to conversation
        assistant_msg: dict[str, Any] = {"role": "assistant", "content": content}
        if tool_calls:
            assistant_msg["tool_calls"] = deepcopy(tool_calls)
        messages.append(assistant_msg)

        if response.get("refusal") or reason == "refusal":
            traj.metadata["termination_kind"] = "provider_refusal"
            if response.get("refusal"):
                traj.metadata["provider_refusal"] = response["refusal"]
            traj.error = f"Provider refusal on round {round_num + 1}; task execution incomplete"
            break

        if reason == "content_filter":
            traj.metadata["termination_kind"] = "provider_filter"
            traj.error = (
                f"Provider content filter on round {round_num + 1}; task execution incomplete"
            )
            break

        if reason in {"length", "max_tokens", "max_output_tokens"}:
            traj.metadata["termination_kind"] = "truncated"
            traj.error = f"Agent response truncated ({stop_reason}) on round {round_num + 1}"
            break

        # Only explicit natural completion can finish a tool-free turn.
        if not tool_calls:
            if reason not in {"stop", "end_turn", "stop_sequence"}:
                traj.metadata["termination_kind"] = "incomplete_provider_turn"
                traj.error = (
                    f"Provider termination {stop_reason!r} without tool calls on round "
                    f"{round_num + 1}; task execution incomplete"
                )
            else:
                traj.metadata["termination_kind"] = "complete"
            break

        # A filtered, paused, unknown, or inconsistent response cannot dispatch
        # pending actions merely because it happens to contain tool arguments.
        if reason not in {"tool_calls", "tool_use"}:
            traj.metadata["termination_kind"] = "incomplete_provider_turn"
            traj.error = (
                f"Provider termination {stop_reason!r} cannot authorize tool continuation "
                f"on round {round_num + 1}; task execution incomplete"
            )
            break
        traj.metadata["termination_kind"] = "tool_continuation"

        # Execute tool calls and add results
        for tc in tool_calls:
            tool_name = tc["name"]
            tool_args = tc.get("arguments", {})
            stage = "dispatch"
            try:
                tool_result = server.call_tool(tool_name, deepcopy(tool_args))
                stage = "serialize_response"
                result_str = json.dumps(tool_result, default=str, allow_nan=False)
            except Exception as exc:
                # An exception can happen after a mutation. Do not invent a
                # failure response, retry the action, or imply rollback.
                traj.error = f"Tool execution error on round {round_num + 1}: {exc}"
                traj.metadata["termination_kind"] = "tool_execution_error"
                traj.metadata["tool_execution_error"] = {
                    "round": round_num + 1,
                    "tool_call_id": tc["id"],
                    "tool_name": tool_name,
                    "stage": stage,
                    "outcome": "unknown",
                    "message": str(exc),
                }
                break

            # Record tool result turn
            traj.add_turn(
                "tool",
                result_str,
                tool_call_id=tc.get("id", ""),
            )

            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": tc.get("id", ""),
                    "content": result_str,
                }
            )
        if traj.error is not None:
            break
    else:
        traj.error = (
            f"Agent exhausted tool round limit ({MAX_TOOL_ROUNDS}) without a final response"
        )
        traj.metadata["stop_reason"] = "tool_round_limit"
        traj.metadata["termination_kind"] = "tool_round_limit"

    traj.duration_seconds = time.monotonic() - start_time
    return traj
