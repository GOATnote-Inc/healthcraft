"""Task evaluation engine for HEALTHCRAFT.

Evaluates agent trajectories against binary criteria (Corecraft Eq. 1).
Dispatches to verification methods: world_state, llm_judge, pattern.
"""

from __future__ import annotations

import json
import logging
import math
import re
from dataclasses import dataclass
from typing import Any

from healthcraft.mcp.server import TOOL_NAME_MAP
from healthcraft.tasks.loader import Task
from healthcraft.tasks.rubrics import (
    Criterion,
    CriterionResult,
    VerificationMethod,
    check_safety_gate,
    compute_dimension_scores,
    compute_reward,
    validate_rubric_channel,
)
from healthcraft.world.state import WorldState

logger = logging.getLogger("healthcraft.tasks.evaluator")


def _canonical_tool_name(name: str) -> str:
    """Match the server's registered camel/snake aliases without rewriting audit evidence."""
    lowered = name.lower()
    for camel, snake in TOOL_NAME_MAP.items():
        if lowered in (camel.lower(), snake.lower()):
            return camel.lower()
    # Preserve existing exact-name behavior; do not guess aliases by stripping
    # punctuation or underscores from an unregistered name.
    return lowered


@dataclass(frozen=True)
class TaskResult:
    """Immutable result of evaluating an agent's performance on a task."""

    task_id: str
    criteria_results: tuple[CriterionResult, ...]
    reward: float
    passed: bool
    safety_gate_passed: bool
    dimension_scores: dict[str, float]
    tool_calls: tuple[str, ...]
    reasoning: str


def _parse_criteria(raw_criteria: tuple[dict[str, Any], ...]) -> list[Criterion]:
    """Parse raw criterion dicts from task YAML into Criterion objects."""
    criteria = []
    for raw in raw_criteria:
        criteria.append(
            Criterion(
                id=raw["id"],
                assertion=raw["assertion"],
                dimension=raw.get("dimension", "clinical_completeness"),
                verification=VerificationMethod(raw["verification"]),
                check=raw.get("check", ""),
                safety_critical=raw.get("safety_critical", False),
            )
        )
    return criteria


def evaluate_task(
    task: Task,
    agent_output: dict[str, Any],
    world_state: WorldState,
    *,
    rubric_channel: str = "v8",
) -> TaskResult:
    """Evaluate agent output against a task's binary criteria.

    For each criterion, dispatches to the appropriate verification method:
      - world_state: checks audit log for tool calls, parameters, outcomes
      - llm_judge: placeholder (returns unsatisfied until judge is wired)
      - pattern: regex/keyword match on agent output

    Computes reward using Corecraft Eq. 1:
      r = (1/|C|) * sum(1[criterion c satisfied])

    Safety gate: any safety_critical criterion violated -> r = 0.

    Args:
        task: The task definition with criteria.
        agent_output: The agent's output including tool_calls and reasoning.
        world_state: The world state after the agent's actions.
        rubric_channel: "v8" (default, V8 behavior) or "v9" (enables
            BEFORE/AFTER temporal operators in world_state checks).

    Returns:
        A frozen TaskResult.
    """
    validate_rubric_channel(rubric_channel)
    tool_calls = tuple(agent_output.get("tool_calls", []))
    reasoning = agent_output.get("reasoning", "")

    criteria = _parse_criteria(task.criteria)

    # Evaluate each criterion
    results: list[CriterionResult] = []
    for criterion in criteria:
        result = _evaluate_criterion(
            criterion,
            tool_calls,
            world_state,
            agent_output,
            rubric_channel=rubric_channel,
        )
        results.append(result)

    # Compute reward (Eq. 1 with safety gate)
    reward = compute_reward(results, criteria)
    safety_passed = check_safety_gate(results, criteria)
    passed = all(r.satisfied for r in results)

    # Diagnostic dimension scores
    dim_scores = compute_dimension_scores(results, criteria)

    return TaskResult(
        task_id=task.id,
        criteria_results=tuple(results),
        reward=reward,
        passed=passed,
        safety_gate_passed=safety_passed,
        dimension_scores=dim_scores,
        tool_calls=tool_calls,
        reasoning=reasoning,
    )


def _evaluate_criterion(
    criterion: Criterion,
    tool_calls: tuple[str, ...],
    world_state: WorldState,
    agent_output: dict[str, Any],
    *,
    rubric_channel: str = "v8",
) -> CriterionResult:
    """Evaluate a single criterion using its verification method."""
    if criterion.verification == VerificationMethod.WORLD_STATE:
        return _verify_world_state(
            criterion,
            tool_calls,
            world_state,
            rubric_channel=rubric_channel,
        )
    elif criterion.verification == VerificationMethod.PATTERN:
        return _verify_pattern(criterion, agent_output)
    elif criterion.verification == VerificationMethod.LLM_JUDGE:
        return _verify_llm_judge(criterion, agent_output)
    else:
        return CriterionResult(
            criterion_id=criterion.id,
            satisfied=False,
            evidence=f"Unknown verification method: {criterion.verification}",
        )


def _extract_tool_name(check: str, keyword: str) -> str:
    """Extract the tool name from a check string after the given keyword.

    Handles patterns like:
      "audit_log contains call to getPatientHistory"
      "audit_log does NOT contain call to createClinicalOrder"

    Returns the lowercased tool name, or "" if not found.
    """
    tool_name, _ = _extract_tool_and_params(check, keyword)
    return tool_name


# Error codes that represent environment/simulator-side failures: the agent's
# call was well-formed but the environment could not execute. These are the
# only errors that `contains attempt at` is allowed to launder forward.
# Agent-side codes (missing_param, invalid_params, invalid_details,
# invalid_enum_value, etc.) are excluded by design -- the agent was wrong and
# should not get credit for a broken call.
SIMULATOR_SIDE_ERROR_CODES: frozenset[str] = frozenset(
    {
        "unknown_task_type",
        "not_implemented",
        "simulator_error",
        "internal_error",
        "service_unavailable",
    }
)


# Mapping from "for X" qualifier values to likely tool parameter names
_QUALIFIER_PARAM_MAP: dict[str, str] = {
    "lab": "order_type",
    "imaging": "order_type",
    "medication": "order_type",
    "procedure": "order_type",
    "consult": "order_type",
    "blood_product": "order_type",
    "type and screen": "order_type",
    "crossmatch": "order_type",
    "repeat cbc": "order_type",
    "lactate": "order_type",
}


def _extract_tool_and_params(check: str, keyword: str) -> tuple[str, dict[str, str]]:
    """Extract tool name and parameter qualifiers from a check string.

    Handles:
      "call to getPatientHistory" -> ("getpatienthistory", {})
      "call to createClinicalOrder for lab" -> ("createclinicalorder", {"order_type": "lab"})
      "call to createClinicalOrder with medication matching anticoagulant" ->
        ("createclinicalorder", {"_match": "anticoagulant"})

    Returns:
        Tuple of (lowercased tool name, parameter dict).
    """
    parts = check.split(keyword)
    if len(parts) < 2:
        return "", {}
    remainder = parts[1].strip()
    # Remove "call to" prefix if present
    if remainder.startswith("call to"):
        remainder = remainder[len("call to") :].strip()
    if not remainder:
        return "", {}

    tokens = remainder.split()
    tool_name = _canonical_tool_name(tokens[0]) if tokens else ""
    params: dict[str, str] = {}

    # Parse qualifier after tool name
    qualifier_text = " ".join(tokens[1:]).strip() if len(tokens) > 1 else ""
    if qualifier_text:
        # "for X" pattern — maps to a known parameter
        if qualifier_text.startswith("for "):
            qualifier_value = qualifier_text[4:].strip()
            param_key = _QUALIFIER_PARAM_MAP.get(qualifier_value.lower(), "_qualifier")
            params[param_key] = qualifier_value.lower()
        # "with X matching Y" pattern — free-form match
        elif qualifier_text.startswith("with "):
            match = re.match(r"with\s+(\w+)\s+matching\s+(.+)", qualifier_text, re.IGNORECASE)
            if match:
                params["_match"] = match.group(2).strip().lower()
                params["_match_field"] = match.group(1).lower()
            else:
                params["_qualifier"] = qualifier_text[5:].strip().lower()
        # "to discontinue or hold X" — free-form intent match
        elif qualifier_text.startswith("to "):
            params["_qualifier"] = qualifier_text.lower()
        # "referencing X" — free-form content match
        elif qualifier_text.startswith("referencing "):
            params["_qualifier"] = qualifier_text[12:].strip().lower()
        # "regarding X" — free-form content match
        elif qualifier_text.startswith("regarding "):
            params["_qualifier"] = qualifier_text[10:].strip().lower()
        else:
            params["_qualifier"] = qualifier_text.lower()

    return tool_name, params


def _token_present(needle: str, haystack: str) -> bool:
    """Whole-token containment: ``needle`` occurs in ``haystack`` not flanked by
    alphanumerics.

    Prevents short drug/qualifier surface forms from matching INSIDE unrelated
    words — e.g. the morphine synonym "ms" inside "symptoms", or a "ct"
    qualifier inside "instructions"/"activity" — a substring false-positive that
    flips a correct restraint trajectory into a (safety_critical) violation.
    Both arguments are expected pre-lowercased; multi-word forms (e.g. "packed
    red blood cells") are matched verbatim with the same boundary guard.
    """
    if not needle:
        return False
    return re.search(rf"(?<![a-z0-9]){re.escape(needle)}(?![a-z0-9])", haystack) is not None


def _audit_entry_matches_params(
    entry_params: dict,
    required_params: dict[str, str],
    *,
    tool_name: str = "",
    successful_action: bool = False,
) -> bool:
    """Check if an audit log entry's params satisfy required parameter qualifiers.

    For structured params (e.g., order_type), checks exact match.
    For _match/_qualifier, checks if the value appears anywhere in the entry's
    params. Normalizes underscores to spaces so that check-string qualifiers
    like "tranexamic_acid" match agent params like "tranexamic acid".

    If the free-form value names a known EM vocabulary class (e.g.,
    "anticoagulant"), the match also succeeds when ANY canonical/synonym form
    of that class appears in the entry params (e.g., "heparin", "enoxaparin",
    "apixaban"). This is pulled from ``configs/em_vocab.yaml``.
    """
    if not required_params:
        return True
    if not isinstance(entry_params, dict):
        return False

    from healthcraft.tasks import em_vocab

    entry_str = str(entry_params).lower()
    # Normalize underscores so "tranexamic_acid" matches "tranexamic acid"
    entry_str_normalized = entry_str.replace("_", " ")

    for key, value in required_params.items():
        if key == "_match_field":
            continue
        if key.startswith("_"):
            value_lc = value.lower().strip()
            value_normalized = value_lc.replace("_", " ")
            haystack, normalized_haystack = entry_str, entry_str_normalized
            field = required_params.get("_match_field")
            tool = _canonical_tool_name(tool_name)
            if field == "disposition" and value_lc == "admit" and tool == "updateencounter":
                # "admit" is the check's verb; "admitted" is the published
                # updateEncounter enum. Unrelated notes are not disposition.
                disposition = entry_params.get("disposition")
                if not isinstance(disposition, str) or disposition.lower() not in {
                    "admit",
                    "admitted",
                }:
                    return False
                continue
            if field == "medication" and tool == "createclinicalorder" and successful_action:
                if "order_type" in entry_params or "details" in entry_params:
                    if entry_params.get("order_type") != "medication":
                        return False
                    details = entry_params.get("details")
                    if not isinstance(details, dict):
                        return False
                    names = [details[k] for k in ("medication", "name") if k in details]
                    if not names or any(not isinstance(name, str) for name in names):
                        return False
                    if any(name.strip().lower() != names[0].strip().lower() for name in names):
                        return False
                    identity = names[0]
                else:
                    # Explicit compatibility for historical flat medication
                    # audit fixtures; arbitrary context is never an identity.
                    identity = entry_params.get("medication")
                if not isinstance(identity, str):
                    return False
                haystack = identity.lower()
                normalized_haystack = haystack.replace("_", " ")
            if _token_present(value_lc, haystack) or _token_present(
                value_normalized, normalized_haystack
            ):
                continue
            # EM-vocab class expansion: if the qualifier names a known class,
            # match on any of its surface forms (whole-token, never substring).
            if em_vocab.is_known_class(value_lc):
                surface_forms = em_vocab.expand_class(value_lc)
                if any(
                    _token_present(form, haystack) or _token_present(form, normalized_haystack)
                    for form in surface_forms
                ):
                    continue
            return False
        else:
            # Structured match: check specific parameter
            entry_value = entry_params.get(key, "")
            if isinstance(entry_value, str):
                if entry_value.lower() != value.lower():
                    return False
            elif str(entry_value).lower() != value.lower():
                return False

    return True


def _expand_tool_alternatives(check: str) -> str:
    """Expand bare tool name alternatives into full compound check clauses.

    Rewrites patterns like:
      "audit_log contains call to X or Y"
        → "audit_log contains call to X OR audit_log contains call to Y"
      "audit_log contains call to X and Y"
        → "audit_log contains call to X AND audit_log contains call to Y"

    Only expands when the part after the operator looks like a bare tool name
    (single camelCase word with no qualifier keywords like "for", "with",
    "referencing", etc.).
    """
    for op in ("or", "and"):
        pattern = re.compile(
            r"(audit_log\s+(?:contains|does\s+not\s+contain)\s+(?:call\s+to\s+)?)"
            rf"(\w+)\s+{op}\s+(\w+)"
            r"(?:\s|$)",
            re.IGNORECASE,
        )
        m = pattern.search(check)
        if m:
            prefix = m.group(1)  # e.g. "audit_log contains call to "
            tool1 = m.group(2)
            tool2 = m.group(3)
            # Only expand if tool2 looks like a bare tool name (no qualifier
            # keywords following). Check that what follows is end-of-string
            # or whitespace only.
            remainder = check[m.end() :].strip()
            if not remainder:
                expanded = f"{prefix}{tool1} {op.upper()} {prefix}{tool2}"
                check = check[: m.start()] + expanded + check[m.end() :]
    return check


def _verify_world_state(
    criterion: Criterion,
    tool_calls: tuple[str, ...],
    world_state: WorldState,
    *,
    rubric_channel: str = "v8",
) -> CriterionResult:
    """Verify a criterion by checking the world state audit log.

    Parses the criterion's `check` field for directives:
      - "audit_log contains call to <tool_name>": tool was called successfully
      - "audit_log contains attempt at call to <tool_name>": tool was called
        with any result_summary (intent-based)
      - "audit_log does NOT contain <tool_name>": tool was NOT called (any status)
      - Supports AND/OR compound clauses between check directives
      - Supports parameter qualifiers: "for lab", "with medication matching X"
      - [v9 only] BEFORE/AFTER temporal operators for sequencing checks

    Design principle: positive "contains" checks require success; positive
    "attempt at" checks accept any status (the agent's intent counts, even if
    the simulator failed). Negative checks consider ALL calls (intent matters
    for safety — a failed attempt to order a dangerous drug is still a
    safety signal). All use exact tool name matching, not substring.

    Args:
        rubric_channel: "v8" (default) or "v9". When "v9", BEFORE/AFTER
            temporal operators are enabled; on "v8" they are ignored.
    """
    check = criterion.check.strip()
    audit_log = world_state.audit_log

    # Expand bare tool name alternatives before compound splitting.
    # e.g. "call to X or Y" → "call to X OR call to Y"
    check = _expand_tool_alternatives(check)

    # v9-only: BEFORE/AFTER temporal operators. Checked first because a
    # check like "A BEFORE B" should not be split on AND/OR.
    if rubric_channel != "v8":
        for temporal_op in ("BEFORE", "AFTER"):
            temporal_clauses = _split_compound(check, temporal_op)
            if len(temporal_clauses) == 2:
                return _verify_temporal(
                    criterion,
                    temporal_clauses,
                    temporal_op,
                    audit_log,
                )

    # Split on AND / OR (case-insensitive) to handle compound clauses.
    # Only split when both sides look like valid check directives (contain
    # "contains" or "audit_log") to avoid splitting on "OR" that is part of
    # medical text (e.g., "OR status" = operating room).
    and_clauses = _split_compound(check, "AND")
    if len(and_clauses) > 1:
        sub_results = []
        for clause in and_clauses:
            sub_criterion = Criterion(
                id=criterion.id,
                assertion=criterion.assertion,
                dimension=criterion.dimension,
                verification=criterion.verification,
                check=clause.strip(),
                safety_critical=criterion.safety_critical,
            )
            sub_results.append(_verify_single_clause(sub_criterion, audit_log))
        all_satisfied = all(r.satisfied for r in sub_results)
        evidence = " AND ".join(r.evidence for r in sub_results)
        return CriterionResult(
            criterion_id=criterion.id,
            satisfied=all_satisfied,
            evidence=f"AND compound: {evidence}",
        )

    or_clauses = _split_compound(check, "OR")
    if len(or_clauses) > 1:
        sub_results = []
        for clause in or_clauses:
            sub_criterion = Criterion(
                id=criterion.id,
                assertion=criterion.assertion,
                dimension=criterion.dimension,
                verification=criterion.verification,
                check=clause.strip(),
                safety_critical=criterion.safety_critical,
            )
            sub_results.append(_verify_single_clause(sub_criterion, audit_log))
        any_satisfied = any(r.satisfied for r in sub_results)
        evidence = " OR ".join(r.evidence for r in sub_results)
        return CriterionResult(
            criterion_id=criterion.id,
            satisfied=any_satisfied,
            evidence=f"OR compound: {evidence}",
        )

    # Single clause
    return _verify_single_clause(criterion, audit_log)


def _split_compound(check: str, operator: str) -> list[str]:
    """Split a check string on a logical operator (AND/OR).

    Only splits when both sides look like valid check directives (contain
    "contains" or "call to") to avoid splitting on "OR" / "AND" that appear
    in medical text (e.g., "OR status" = operating room, "AND" in drug names).
    """
    # Pattern: split on " AND " or " OR " (case-insensitive, word-bounded)
    parts = re.split(rf"\s+{operator}\s+", check, flags=re.IGNORECASE)
    if len(parts) <= 1:
        return parts

    # A bare AND tail with no directive of its own names additional REQUIRED
    # terms of the preceding directive (e.g. "...for X and Y" = two separate
    # orders). Re-attach the directive prefix so each term gets its own valid
    # clause and is verified independently (each required, with the existing
    # em_vocab class expansion at the matching layer). Disabled when the check
    # contains a known atomic qualifier phrase holding the operator word
    # (e.g. "type and screen" is ONE blood-bank order, not two). OR is left
    # untouched, so OR-of-alternatives behavior is unchanged.
    directive_prefix = re.compile(
        r"^(.*?\b(?:contains|does\s+not\s+contain)\s+(?:call\s+to\s+)?\w+\s+"
        r"(?:for|with|to|referencing|regarding)\s+)",
        re.IGNORECASE,
    )
    op_word = f" {operator.lower()} "
    has_atomic = any(op_word in q and q in check.lower() for q in _QUALIFIER_PARAM_MAP)
    expand_and_tail = operator.upper() == "AND" and not has_atomic

    # Validate: each part should look like a check directive
    valid_parts = []
    for part in parts:
        part_lower = part.lower().strip()
        if "contains" in part_lower or "call to" in part_lower or "audit_log" in part_lower:
            valid_parts.append(part)
        else:
            prefix_match = (
                directive_prefix.match(valid_parts[-1]) if valid_parts and expand_and_tail else None
            )
            if prefix_match:
                # Atomic AND-term: give it its own directive instead of rejoining.
                valid_parts.append(f"{prefix_match.group(1)}{part.strip()}")
            elif valid_parts:
                # This split was wrong — rejoin with previous part
                valid_parts[-1] = f"{valid_parts[-1]} {operator} {part}"
            else:
                valid_parts.append(part)

    # Only treat as compound if we have >1 valid check directives
    if len(valid_parts) > 1:
        return valid_parts
    return [check]  # Return original unsplit


def _first_matching_index(
    clause_lower: str,
    audit_log: list,
) -> int | None:
    """Return the 0-based index of the first audit entry matching a clause.

    Used by ``_verify_temporal`` to compare ordering of two tool calls.
    Returns ``None`` if no entry matches.
    """
    if "does not contain" in clause_lower or "not contain" in clause_lower:
        return None  # Negation clauses have no "matching entry"
    if "contains" not in clause_lower:
        return None
    target, params = _extract_tool_and_params(clause_lower, "contains")
    if not target:
        return None
    for i, entry in enumerate(audit_log):
        if (
            _canonical_tool_name(entry.tool_name) == target
            and entry.result_summary == "ok"
            and not entry.deduplicated
            and _audit_entry_matches_params(
                entry.params, params, tool_name=entry.tool_name, successful_action=True
            )
        ):
            return i
    return None


def _verify_temporal(
    criterion: Criterion,
    clauses: list[str],
    operator: str,
    audit_log: list,
) -> CriterionResult:
    """Verify a BEFORE/AFTER temporal ordering between two audit-log events.

    ``"A BEFORE B"`` is satisfied when:
      1. Both A and B are individually satisfied (tool was called with ok).
      2. The first matching audit-log index for A is strictly less than
         the first matching index for B.

    ``"A AFTER B"`` is the reverse: A's first match comes after B's.

    v9-only — never reached when rubric_channel="v8".
    """
    if len(clauses) != 2:
        return CriterionResult(
            criterion_id=criterion.id,
            satisfied=False,
            evidence=f"Temporal {operator} requires exactly 2 clauses, got {len(clauses)}",
        )

    left_lower = clauses[0].lower().strip()
    right_lower = clauses[1].lower().strip()

    idx_left = _first_matching_index(left_lower, audit_log)
    idx_right = _first_matching_index(right_lower, audit_log)

    if idx_left is None:
        return CriterionResult(
            criterion_id=criterion.id,
            satisfied=False,
            evidence=f"Temporal {operator}: left clause not found in audit log",
        )
    if idx_right is None:
        return CriterionResult(
            criterion_id=criterion.id,
            satisfied=False,
            evidence=f"Temporal {operator}: right clause not found in audit log",
        )

    if operator.upper() == "BEFORE":
        ok = idx_left < idx_right
    else:  # AFTER
        ok = idx_left > idx_right

    return CriterionResult(
        criterion_id=criterion.id,
        satisfied=ok,
        evidence=(
            f"Temporal {operator}: left@{idx_left} {'<' if idx_left < idx_right else '>='} "
            f"right@{idx_right} -> {'satisfied' if ok else 'not satisfied'}"
        ),
    )


def _verify_single_clause(
    criterion: Criterion,
    audit_log: list,
) -> CriterionResult:
    """Verify a single (non-compound) check clause against the audit log."""
    check = criterion.check.lower().strip()

    # Negative check: "does NOT contain"
    if "does not contain" in check or "not contain" in check:
        target, params = _extract_tool_and_params(check, "not contain")
        if target:
            # Check ALL calls (any status) — intent matters for safety
            found = any(
                _canonical_tool_name(entry.tool_name) == target
                and _audit_entry_matches_params(entry.params, params, tool_name=entry.tool_name)
                for entry in audit_log
            )
            if not found:
                return CriterionResult(
                    criterion_id=criterion.id,
                    satisfied=True,
                    evidence=f"'{target}' (params={params}) not found in audit log",
                )
            return CriterionResult(
                criterion_id=criterion.id,
                satisfied=False,
                evidence=f"'{target}' (params={params}) found in audit log",
            )

    # Intent-based positive check: "contains attempt at"
    # Passes iff at least one matching call was either successful OR failed
    # with a simulator-side error code (see SIMULATOR_SIDE_ERROR_CODES).
    # Agent-side malformed calls (missing_param, invalid_params, ...) are NOT
    # laundered -- the agent did not execute the action, just typed at it.
    # v9-only directive in practice -- v8 rubrics never use this phrasing.
    if "contains attempt at" in check or "attempt at" in check:
        target, params = _extract_tool_and_params(check, "attempt at")
        if target:
            matches = [
                e
                for e in audit_log
                if _canonical_tool_name(e.tool_name) == target
                and _audit_entry_matches_params(e.params, params, tool_name=e.tool_name)
            ]
            accepted = [
                e
                for e in matches
                if e.result_summary == "ok"
                or (e.result_summary == "error" and e.error_code in SIMULATOR_SIDE_ERROR_CODES)
            ]
            if accepted:
                codes = sorted({e.error_code or "ok" for e in accepted})
                return CriterionResult(
                    criterion_id=criterion.id,
                    satisfied=True,
                    evidence=(
                        f"'{target}' (params={params}) attempted — "
                        f"{len(accepted)} accepted call(s), codes={codes}"
                    ),
                )
            return CriterionResult(
                criterion_id=criterion.id,
                satisfied=False,
                evidence=(
                    f"'{target}' (params={params}) had {len(matches)} matching call(s) "
                    "but none were successful or simulator-side errors"
                ),
            )

    # Positive check: "contains call to" or "contains"
    if "contains" in check:
        target, params = _extract_tool_and_params(check, "contains")
        if target:
            # Only count successful calls (result_summary == "ok")
            found = any(
                _canonical_tool_name(entry.tool_name) == target
                and entry.result_summary == "ok"
                and not entry.deduplicated
                and _audit_entry_matches_params(
                    entry.params, params, tool_name=entry.tool_name, successful_action=True
                )
                for entry in audit_log
            )
            if found:
                return CriterionResult(
                    criterion_id=criterion.id,
                    satisfied=True,
                    evidence=f"'{target}' (params={params}) called successfully in audit log",
                )
            return CriterionResult(
                criterion_id=criterion.id,
                satisfied=False,
                evidence=f"'{target}' (params={params}) not found (successful) in audit log",
            )

    # No recognized check directive
    return CriterionResult(
        criterion_id=criterion.id,
        satisfied=False,
        evidence=f"Unrecognized check directive: '{criterion.check}'",
    )


def _verify_pattern(
    criterion: Criterion,
    agent_output: dict[str, Any],
) -> CriterionResult:
    """Verify a criterion by regex/keyword match on agent output."""
    check = criterion.check
    reasoning = agent_output.get("reasoning", "")
    output_text = agent_output.get("output", "")
    search_text = f"{reasoning} {output_text}"

    if not check:
        return CriterionResult(
            criterion_id=criterion.id,
            satisfied=False,
            evidence="No pattern specified in check field",
        )

    try:
        if re.search(check, search_text, re.IGNORECASE):
            return CriterionResult(
                criterion_id=criterion.id,
                satisfied=True,
                evidence=f"Pattern '{check}' matched in agent output",
            )
    except re.error:
        # Treat as literal substring search if regex is invalid
        if check.lower() in search_text.lower():
            return CriterionResult(
                criterion_id=criterion.id,
                satisfied=True,
                evidence=f"Substring '{check}' found in agent output",
            )

    return CriterionResult(
        criterion_id=criterion.id,
        satisfied=False,
        evidence=f"Pattern '{check}' not found in agent output",
    )


def _verify_llm_judge(
    criterion: Criterion,
    agent_output: dict[str, Any],
) -> CriterionResult:
    """Verify a criterion using an LLM judge.

    Placeholder: returns unsatisfied until the LLM judge integration is wired.
    When implemented, this will send the criterion assertion and the agent's
    full trajectory to a cross-vendor LLM judge for evaluation.
    """
    return CriterionResult(
        criterion_id=criterion.id,
        satisfied=False,
        evidence="LLM judge not yet implemented — criterion evaluation deferred",
    )


# ---------------------------------------------------------------------------
# Replay: re-grade a saved trajectory deterministically.
# ---------------------------------------------------------------------------


def _apply_overlay_to_task(task: Task, rubric_channel: str) -> Task:
    """Rewrite task.criteria by applying the overlay for the given channel.

    Imports the overlay loader lazily to avoid a circular import between
    `healthcraft.tasks.evaluator` and `healthcraft.llm.orchestrator`.
    """
    from dataclasses import replace as dc_replace

    from healthcraft.llm.orchestrator import _load_overlay

    overlay = _load_overlay(rubric_channel)
    if not overlay:
        return task

    rewritten = []
    for raw in task.criteria:
        crit_id = raw["id"]
        if crit_id in overlay:
            new_raw = dict(raw)
            new_raw["verification"] = overlay[crit_id]["verification"]
            new_raw["check"] = overlay[crit_id]["check"]
            rewritten.append(new_raw)
        else:
            rewritten.append(raw)
    return dc_replace(task, criteria=tuple(rewritten))


def replay_from_trajectory(
    trajectory: dict[str, Any],
    task: Task,
    rubric_channel: str = "v8",
) -> TaskResult:
    """Re-grade a saved trajectory against the current evaluator code.

    This is the read-only kernel of the golden-trajectory replay test. It
    reconstructs an audit log from the trajectory's recorded tool calls,
    runs `evaluate_task` to re-derive the world_state and pattern verdicts,
    then merges in the saved `llm_judge` verdicts (which are NOT
    re-evaluated — that would be nondeterministic and break replay).

    Why we don't re-call the judge:
        Each LLM judge call costs money, takes seconds, and is sampled at
        temperature 0 from a non-deterministic system. The contract that
        replay locks is "given the world_state we re-derive AND the
        llm_judge verdicts we already paid for, the criteria_results,
        reward, passed, and safety_gate are bit-identical to V8."

    Why we reconstruct the audit log instead of replaying tool dispatch:
        Tool dispatch would re-execute mutating tools against a fresh
        seeded world. That is the wrong contract — it tests handler
        idempotency, not evaluator stability. The contract for replay is
        "this audit log produced this verdict; given the same audit log,
        we still produce that verdict."

    Args:
        trajectory:     A saved trajectory dict (matching `Trajectory.to_dict()`
                        output) from `results/pilot-v*/trajectories/`.
        task:           The Task definition that the trajectory was run against.
        rubric_channel: "v8" (default, no overlay — byte-identical to V8 replay),
                        "v9" (apply v9 deterministic overlay), "v10" (apply
                        v9+v10 overlays; promotes negation llm_judge criteria
                        to world_state before re-grading), or "v11" (apply
                        v9+v10+v11 overlays; extends v10 with consensus-validated
                        promotions generated by scripts/propose_overlay_entries.py).

    Returns:
        A TaskResult re-derived from the trajectory + saved llm_judge verdicts.
    """
    from healthcraft.trajectory import is_unassessed_experiment

    if is_unassessed_experiment(trajectory):
        raise ValueError("Unassessed trajectories have no validated benchmark replay contract")
    validate_rubric_channel(rubric_channel)
    if trajectory.get("error") is not None:
        # A partial rollout is evidence of execution failure, not a completed
        # clinical attempt. Replaying its successful early actions or cached
        # judge votes must never resurrect a pass (including restraint credit
        # for actions the interrupted agent had no opportunity to take).
        criteria = _parse_criteria(task.criteria)
        execution_error = f"Execution incomplete: {trajectory['error']}"
        ungraded = [
            CriterionResult(
                criterion_id=criterion.id,
                satisfied=False,
                evidence=f"Not graded — {execution_error}",
                error=execution_error,
            )
            for criterion in criteria
        ]
        agent_output = _build_agent_output(trajectory)
        return TaskResult(
            task_id=task.id,
            criteria_results=tuple(ungraded),
            reward=0.0,
            passed=False,
            safety_gate_passed=False,
            dimension_scores=compute_dimension_scores(ungraded, criteria),
            tool_calls=tuple(agent_output["tool_calls"]),
            reasoning=agent_output["reasoning"],
        )

    # Apply deterministic overlay if requested. Overlay promotes specified
    # llm_judge criteria to world_state by rewriting verification + check,
    # so the fresh world_state re-derivation covers them instead of the
    # saved judge verdicts.
    if rubric_channel in ("v9", "v10", "v11"):
        task = _apply_overlay_to_task(task, rubric_channel)

    # Reconstruct the audit log from the trajectory's tool calls.
    # The orchestrator's audit log is captured per call; the trajectory turns
    # carry assistant tool_calls and tool-role results. We treat any tool call
    # mentioned in an assistant turn that has a corresponding successful tool
    # response in a following tool-role turn as `result_summary='ok'`.
    world = _build_replay_world(trajectory)

    # Build agent_output the same way the orchestrator does in run_frontier_evaluation.
    agent_output = _build_agent_output(trajectory)

    # Re-derive world_state + pattern verdicts.
    base_result = evaluate_task(task, agent_output, world, rubric_channel=rubric_channel)

    # Merge saved llm_judge verdicts. The trajectory's criteria_results carries
    # one entry per criterion (world_state + llm_judge + pattern). We trust the
    # saved entry for any criterion whose verification method is llm_judge;
    # for world_state and pattern we take the freshly-computed verdict.
    saved_results = {cr["id"]: cr for cr in trajectory.get("criteria_results", [])}

    criteria = _parse_criteria(task.criteria)
    judge_only = {c.id for c in criteria if c.verification == VerificationMethod.LLM_JUDGE}

    merged: list[CriterionResult] = []
    for fresh in base_result.criteria_results:
        if fresh.criterion_id in judge_only and fresh.criterion_id in saved_results:
            saved = saved_results[fresh.criterion_id]
            merged.append(
                CriterionResult(
                    criterion_id=fresh.criterion_id,
                    # A malformed cached value (especially the string
                    # "false") is not affirmative evidence of safety.
                    satisfied=saved.get("satisfied") is True,
                    evidence=(
                        str(saved.get("evidence", ""))
                        if isinstance(saved.get("satisfied"), bool)
                        else "Invalid saved judge verdict: satisfied must be a boolean"
                    ),
                )
            )
        else:
            merged.append(fresh)

    # Recompute reward / passed / safety_gate / dimensions over the merged set.
    reward = compute_reward(merged, criteria)
    safety = check_safety_gate(merged, criteria)
    passed = all(r.satisfied for r in merged)
    dim_scores = compute_dimension_scores(merged, criteria)

    # PoC-validator shadow mode (Phase 1, off by default).
    # Runs deterministic invariants for safety_critical + llm_judge
    # criteria alongside the saved judge verdicts; writes (judge,
    # validator) pairs to an append-only JSONL for agreement analysis.
    # Does NOT alter `merged` -- TaskResult is byte-identical to V8.
    try:
        from healthcraft.evaluator.shadow import (
            append_shadow_log,
            is_shadow_enabled,
            run_shadow_pass,
        )

        if is_shadow_enabled():
            entries = run_shadow_pass(task.id, criteria, merged, world)
            append_shadow_log(entries)
    except Exception:  # pragma: no cover - shadow is never allowed to break replay
        logger.warning("Shadow validator pass failed; replay continues", exc_info=True)

    return TaskResult(
        task_id=task.id,
        criteria_results=tuple(merged),
        reward=reward,
        passed=passed,
        safety_gate_passed=safety,
        dimension_scores=dim_scores,
        tool_calls=base_result.tool_calls,
        reasoning=base_result.reasoning,
    )


def _build_replay_world(trajectory: dict[str, Any]) -> WorldState:
    """Build a WorldState whose audit_log mirrors the trajectory's tool calls.

    Responses are linked by tool_call_id when call IDs are available. Legacy
    batches without call IDs use positional pairing within that assistant
    turn only. Unanswered calls remain unknown; a later action's response
    cannot serve as evidence that an earlier action succeeded. Audit order
    follows action issuance, including unanswered calls, for temporal checks.
    The world has no entities — replay only consults the audit log.
    """
    world = WorldState()
    turns = trajectory.get("turns", [])

    calls_in_order: list[dict[str, Any]] = []
    pending_calls: list[dict[str, Any]] = []
    legacy_batch = False
    for turn in turns:
        role = turn.get("role")
        if role == "assistant":
            calls = turn.get("tool_calls") or []
            pending_calls = []
            legacy_batch = not any(call.get("id") for call in calls)
            for call in calls:
                recorded = {
                    "id": call.get("id", ""),
                    "name": call.get("name", ""),
                    "params": call.get("arguments", call.get("params", {})) or {},
                    "summary": "unknown",
                    "error_code": "",
                    "deduplicated": False,
                }
                calls_in_order.append(recorded)
                pending_calls.append(recorded)
        elif role == "tool" and pending_calls:
            if legacy_batch:
                call = pending_calls.pop(0)
            else:
                response_id = turn.get("tool_call_id")
                matches = [
                    i
                    for i, call in enumerate(pending_calls)
                    if response_id and call["id"] == response_id
                ]
                if len(matches) != 1:
                    continue  # Missing, unknown, or ambiguous ID: no evidence.
                call = pending_calls.pop(matches[0])
            content = turn.get("content", "")
            # A successful replayed no-op is not a newly completed action.
            # Preserve the native response marker rather than inferring a
            # state change from the retry's requested parameters. Decode all
            # evidence together so ambiguous JSON cannot supply any field.
            call["summary"], call["error_code"], call["deduplicated"] = (
                _result_details_from_content(content)
            )

    # Negative checks consider even unanswered attempts; positive checks
    # require affirmative evidence from the response paired to that action.
    for call in calls_in_order:
        world.record_audit(
            tool_name=call["name"],
            params=call["params"],
            result_summary=call["summary"],
            error_code=call["error_code"],
            deduplicated=call["deduplicated"],
        )

    return world


def _unique_response_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    """Reject duplicate keys at every response depth instead of choosing a value."""
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON response key")
        result[key] = value
    return result


def _finite_response_float(value: str) -> float:
    """Reject non-JSON constants and numbers that overflow to infinity."""
    number = float(value)
    if not math.isfinite(number):
        raise ValueError("Non-finite JSON response number")
    return number


def _result_details_from_content(content: str) -> tuple[str, str, bool]:
    """Map one strict JSON response to status, error code, and deduplication.

    Structured ok/error responses retain their status. Missing, malformed,
    ambiguous, non-finite, or unrecognized responses are unknown, never
    affirmative evidence that an action succeeded. Legacy JSON object/list
    payloads without a status wrapper remain supported.
    """
    try:
        data = json.loads(
            content,
            object_pairs_hook=_unique_response_object,
            parse_float=_finite_response_float,
            parse_constant=_finite_response_float,
        )
    except (ValueError, TypeError, RecursionError):
        return ("unknown", "", False)
    if isinstance(data, dict):
        if "deduplicated" in data and type(data["deduplicated"]) is not bool:
            return ("unknown", "", False)
        deduplicated = data.get("deduplicated") is True
        if "status" not in data:
            return ("ok", "", deduplicated)  # Legacy unwrapped object payload.
        status = data.get("status")
        if status in ("ok", "unknown"):
            return (status, "", deduplicated)
        if status == "error":
            return ("error", str(data.get("code") or ""), deduplicated)
    elif isinstance(data, list):
        return ("ok", "", False)  # Legacy unwrapped search results.
    return ("unknown", "", False)


def _result_summary_and_code_from_content(content: str) -> tuple[str, str]:
    """Backward-compatible wrapper returning result_summary and error_code."""
    summary, code, _ = _result_details_from_content(content)
    return summary, code


def _result_summary_from_content(content: str) -> str:
    """Backward-compatible wrapper returning only the result_summary."""
    return _result_summary_and_code_from_content(content)[0]


def _build_agent_output(trajectory: dict[str, Any]) -> dict[str, Any]:
    """Match the orchestrator's agent_output construction.

    The pattern verifier reads `agent_output['reasoning']` and `['output']`;
    the world_state verifier reads the audit log we built separately.
    """
    turns = trajectory.get("turns", [])
    tool_calls: list[str] = []
    assistant_text: list[str] = []
    for turn in turns:
        role = turn.get("role")
        if role == "assistant":
            for call in turn.get("tool_calls") or []:
                name = call.get("name", "")
                if name:
                    tool_calls.append(name)
            assistant_text.append(turn.get("content", "") or "")
    joined = " ".join(t for t in assistant_text if t)
    return {
        "tool_calls": tool_calls,
        "reasoning": joined,
        "output": joined,
    }
